By: Eric Wu, 30055876

github repo link: https://github.com/Font-Of-Life/Some-Chat-thing

special instructions:
1. upon downloading/moving the folder contained in the zip file to your desktop, open up the command terminal
and run "npm install" while in that folder directory.
2. then type in "node index.js" to host the chat site.
3. then go onto a internet browser and type in the URL: http://localhost:3000/